import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'ass5task6';
  name:string;
  constructor(private route: ActivatedRoute,private httpClient: HttpClient) { 
    console.log("hrllo");
    this.route.params.subscribe(params => {this.name = params['name'];});
    console.log ("ID value is : "+this.name);
   
}
movie: any=[];
id:number;
img:string;
genre:string;
imdb:string;

ngOnInit(){
  this.httpClient.get("../assets/movies.json"). subscribe (data =>
            {
              console.log(data);
               this.movie=data;
             console.log("movie details")
             console.log(this.movie.length);  
             for (let index = 0; index < this.movie.length; index++) {
               console.log(this.name.toLowerCase()+" "+(this.movie[index].name).toLowerCase());
               if(this.name==this.movie[index].name){
                 console.log("inside if");
                 this.id=this.movie[index].movie_id;
                 this.img=this.movie[index].img;
                 this.genre=this.movie[index].genre;
                 this.imdb=this.movie[index].imdb;
                 console.log(this.id+" "+this.img+" "+this.imdb+" "+this.genre);
               }
               
             }
            }
            
            );  
    console.log(this.id+" "+this.img+" "+this.imdb+" "+this.genre);
    
     
}

}
