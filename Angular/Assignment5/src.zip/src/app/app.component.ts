import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, ElementRef } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name:string = "Welcome to angular course!!";
  title = 'assignment1';
  num1:number =20;
  num2:number = 10;
  num3:number=0;
  num4:number=0;
  firstName:string;
  lastName:string;
  fname:string;
  lname:string;
  basic:number=0;
  hra:number=0;
  da:number=0;
  ded:number=0;
  it:number=0;
  disable:boolean=true;
  h1color:string ="Aqua"
  lcase:string="vineela";
  ucase:string="VINEELA";
  selected:string="INR"
  money:string;
  inr:boolean=false;
  dollar:boolean=false;
  Value:number=2000;
  todayDate = new Date();
  perce:number;
  address={"raju":"Mehdipatnma","ramesh":"Banjara hills","Manju":"Jubilee Hills","Shantan":"Secunderabad","Pawan":"Koti"}
  names = ["Raju","Ramu","Manju","Mahesh","Rashmi","Roshni","Nagasree","Mehthab","Johnny"];
  months = ["March","April","May","June","July","August","September","October"];
  Character ={
    actor_name: String,
    character_name: String,
    gender: String,
    status: String
}
  characters=[
    {
    actor_name: 101,
    character_name: 'Rajesh',
    gender: 'Male',
        status: 'IT'
    },
    {
    actor_name: 102,
    character_name: 'Abhay',
    gender: 'Male',
    status: 'Sales'
    },
    {
    actor_name: 203,
    character_name: 'Roshni',
    gender: 'Female',
    status: 'Marketing'
    },
    {
    actor_name: 205,
    character_name: 'Michelle',
    gender: 'Female',
    status: 'Cyber Security'
    }
  ];

  onClick(event$){
    console.log("Mouse was clicked",event$);
    alert("You have pressed the button");
  }
  display(){
    alert("Hello "+this.fname+" "+this.lname);
  }
  onSubmit(form: NgForm){
    console.log(form.value.hra,form.value.basic,form.value.da,form.value.ded,form.value.it);
    this.hra=form.value.hra;
    this.basic=form.value.basic;
    this.da=form.value.da;
    this.ded=form.value.ded;
    this.it=form.value.it
    alert("Total Salary:"+(this.hra+this.basic+this.da-(this.ded+this.it)));
  }
  changeColor(){
    this.h1color="green";
  }
  curreny(){
   if(this.selected=="INR"){
     this.inr=true;
   }
   else{
    this.dollar=true;
   }
 }

}
