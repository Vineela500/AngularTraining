import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pvr',
  templateUrl: './pvr.component.html',
  styleUrls: ['./pvr.component.css']
})
export class PvrComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
