import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inox',
  templateUrl: './inox.component.html',
  styleUrls: ['./inox.component.css']
})
export class InoxComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
