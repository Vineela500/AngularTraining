import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theater-home',
  templateUrl: './theater-home.component.html',
  styleUrls: ['./theater-home.component.css']
})
export class TheaterHomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
