import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { RouterModule, Routes } from '@angular/router';
import { MoviesComponent } from './movies/movies.component';
import { TheaterComponent } from './theater/theater.component';
import { InoxComponent } from './theater/inox/inox.component';
import { TheaterHomeComponent } from './theater/theater-home/theater-home.component';
import { PvrComponent } from './theater/pvr/pvr.component';
import { ThorComponent } from './movies/thor/thor.component';
import { ShutterComponent } from './movies/shutter/shutter.component';
import { GoneComponent } from './movies/gone/gone.component';

const appRoutes: Routes = [
  {
    path:'home',
    component: HomeComponent
  },
  { path: '', redirectTo: '/home', pathMatch: 'full' } ,
  {
      path:'movies',
      component: MoviesComponent
    },
    {
      path:'movies/shutter',
      component: ShutterComponent
    },
    {
      path:'movies/gone',
      component: GoneComponent
    },
    {
      path:'theater',
      component: TheaterHomeComponent
    },
    {
      path : 'theater/inox',
      component: InoxComponent
    },
    {
      path : 'theater/pvr',
      component: PvrComponent
    },
    {
      path:'movies/thor',
      component: ThorComponent
    },
   
  
]
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    MoviesComponent,
    TheaterComponent,
    InoxComponent,
    TheaterHomeComponent,
    PvrComponent,
    ThorComponent,
    ShutterComponent,
    GoneComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
