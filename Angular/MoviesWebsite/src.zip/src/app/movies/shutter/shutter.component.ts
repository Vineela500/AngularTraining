import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shutter',
  templateUrl: './shutter.component.html',
  styleUrls: ['./shutter.component.css']
})
export class ShutterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
