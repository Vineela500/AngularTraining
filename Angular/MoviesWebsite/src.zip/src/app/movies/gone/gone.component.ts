import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gone',
  templateUrl: './gone.component.html',
  styleUrls: ['./gone.component.css']
})
export class GoneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
