import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thor',
  templateUrl: './thor.component.html',
  styleUrls: ['./thor.component.css']
})
export class ThorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
