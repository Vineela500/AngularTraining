import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'testnew';
  rail: any=[];
  movie: any=[];
constructor(private httpClient: HttpClient){

}
ngOnInit()
  {    this.httpClient.get("/assets/assignment/rail.json"). subscribe (data =>
          {
            console.log(data);
             this.rail=data;
           console.log(this.rail);          
          }, 
          
          );       
     this.httpClient.get("/assets/assignment/movie.json"). subscribe (data =>
            {
              console.log(data);
               this.movie=data;
             console.log(this.movie);          
            }, 
            
            );       
}
}
