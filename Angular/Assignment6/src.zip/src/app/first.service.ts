import { Variable } from '@angular/compiler/src/render3/r3_ast';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FirstService {

  constructor() { }
  getDate():Date{
     let today=new Date();
     return today;
  }
  add(n1:number, n2:number):number{
      let total=n1+n2;
      return total;
  }
  sub(n1:number, n2:number):number{
    let total=n1-n2;
    return total;
  }
  mul(n1:number, n2:number):number{
    let total=n1*n2;
    return total;
}
div(n1:number, n2:number):number{
  let total=n1/n2;
  return total;
}
rem(n1:number, n2:number):number{
 
  let total=n1%n2;
  return total;
}
arth(n1:number,n2:number):Array<number>{
  let total=[];
  total.push(n1+n2);
  total.push(n1-n2);
  total.push(n1*n2);
  total.push(n1/n2);
  total.push(n1%n2);
  return total;
}
}
