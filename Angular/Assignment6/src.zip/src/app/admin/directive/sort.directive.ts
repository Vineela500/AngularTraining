import { Directive } from '@angular/core';

@Directive({
  selector: '[appSort]'
})
export class SortDirective {

  constructor() { }

}
