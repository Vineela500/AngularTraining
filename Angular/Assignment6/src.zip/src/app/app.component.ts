import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Employee } from './app.model';
import { FirstService } from './first.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'assignment2';
  today:Date;
  date1:boolean = false ;
  time1:boolean = false;
  formated_date:boolean = false; 
  num1:number=0;
  num2:number=0;
  searchText:string="";
  fname:string="";
  lname:string="";
  add1:string="";
  constructor(private myservice: FirstService){
      
  }
  ngOnInit(){
    this.today = this.myservice.getDate();
    console.log("2019-06-10"<"2019-06-02");
  }
  
  getDate():void{
    this.date1=true;
    this.time1=false;
    this.formated_date=false;
  }
  getTime():void{
    this.date1=false;
    this.time1=true;
    this.formated_date=false;
  }
  dateFormatted():void{
    this.date1=false;
    this.time1=false;
    this.formated_date=true;
  }
  add(){
    alert(this.myservice.add(this.num1,this.num2));
  }
  sub(){
    alert(this.myservice.sub(this.num1,this.num2));
  }
  mul(){
    alert(this.myservice.mul(this.num1,this.num2));
  }
  div(){
    alert(this.myservice.div(this.num1,this.num2));
  }
  rem(){
    alert(this.myservice.rem(this.num1,this.num2));
  }
  total = [];
  sum:number=0;
  sub1:number=0;
  mul1:number=0;
  div1:number=0;
  rem1:number=0;
  arth(){
    this.total=this.myservice.arth(20,10);
    this.sum=this.total[0];
    this.sub1=this.total[1];
    this.mul1=this.total[2];
    this.div1=this.total[3];
    this.rem1=this.total[4];
  }
  message:string;
  msg:boolean=false;
  msgbool(){
    this.msg=true;
    this.message="This message is from parent";
  }
  msg2:string;
 
  ctop(e){
    alert(e);
    
    this.message="";
    this.msg2="";
  }
  emp: Employee[] =[
    new Employee(10,"Vineela","IT",21),
    new Employee(21,"Ramesh","IT",30),
    new Employee(30,"Abhay","Sales",25),
    new Employee(40,"John","HR",40),
    new Employee(25,"Rahul","Marketing",34)
  ];
  name1:string;
  id1:number;
  dept1:string;
  age1:number;
  addEmp(form: NgForm){
    const value=form.value;
    this.name1=form.value.name1;
    this.id1=form.value.id1;
    this.dept1=form.value.dept1;
    this.age1=form.value.age1;
    const newEmp= new Employee(this.id1,this.name1,this.dept1,this.age1);
    this.emp.push(newEmp);
  }
  id:number;
  del(){
    let el=0;
    for (let index = 0; index < this.emp.length; index++) {
      const element = this.emp[index].id;
      if(element==this.id){
          el=index;
      }
      
    }
    this.emp.splice(el,1);
  }
  deptbool:boolean=false;
  agebool:boolean=false;
  dept(){
   this.deptbool=true;
  }
  age(){
    this.agebool=true;
  }
  updateDept(form: NgForm){
    this.deptbool=false;
    let idup=form.value.id;
    let deptup=form.value.dept;
    let el=0;
    let flag=0;
    for (let index = 0; index < this.emp.length; index++) {
      const element = this.emp[index].id;
      if(element==idup){
         el =index;
         flag=1;
      }
      
    }
    if(flag==1){
    let nameup=this.emp[el].name;
    let ageup=this.emp[el].age;
    this.emp.splice(el,1);
    const newEmp=new Employee(idup,nameup,deptup,ageup);
    this.emp.push(newEmp);
    alert("Updated department successfully");
    }
    else{
     alert("You have entered wrong id ");
    }

  }
  updateAge(form: NgForm){
    this.agebool=false;
    this.deptbool=false;
    let idup=form.value.id;
    let ageup=form.value.age;
    let el=0;
    let flag=0;
    for (let index = 0; index < this.emp.length; index++) {
      const element = this.emp[index].id;
      if(element==idup){
         el =index;
         flag=1;
      }
      
    }
    if(flag==1){
    let nameup=this.emp[el].name;
    let deptup=this.emp[el].dept;
    this.emp.splice(el,1);
    const newEmp=new Employee(idup,nameup,deptup,ageup);
    this.emp.push(newEmp);
    alert("Updated age successfully");
    }
    else{
      alert("You have entered wrong id");
    }

  }
  onSubmit(form: NgForm){
    console.log(form.value.hra,form.value.basic,form.value.da,form.value.ded,form.value.it);
    console.log("20">"30");
    
  }
  term: string;

  filterData = [
    {
      firstName: 'Celestine',
      lastName: 'Schimmel',
      address: '7687 Jadon Port',
      
    },
    {
      firstName: 'Johan',
      lastName: 'Ziemann PhD',
      address: '156 Streich Ports'
    },
    {
      firstName: 'Lizzie',
      lastName: 'Schumm',
      address: '5203 Jordon Center'
    },
    {
      firstName: 'Gavin',
      lastName: 'Leannon',
      address: '91057 Davion Club'
    },
    {
      firstName: 'Lucious',
      lastName: 'Leuschke',
      address: '16288 Reichel Harbor'
    }
  ]
  reset(){
    this.fname="";
    this.lname="";
    this.add1="";
    console.log(this.fname);
  }
}
