import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FirstService } from './first.service';
import { FormsModule } from '@angular/forms';
import { Comp1Component } from './comp1/comp1.component';
import { Comp2Component } from './comp2/comp2.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { FilterPipe } from './filter.pipe';
import { SortDirective } from './directive/sort.directive';
//import { Ng2SearchPipeModule } from 'ng2-search-filter';

@NgModule({
  declarations: [
    AppComponent,
    Comp1Component,
    Comp2Component,
    FilterPipe,
    SortDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
   // ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production }),
   // Ng2SearchPipeModule
  ],
  providers: [FirstService],
  bootstrap: [AppComponent]
})
export class AppModule { }
