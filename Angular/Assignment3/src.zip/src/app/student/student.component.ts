import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Student } from '../student';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  id:number =0;
  constructor(private route: ActivatedRoute) { 
    console.log("hrllo");
    this.route.params.subscribe(params => {this.id = +params['id'];});
    console.log ("ID value is : "+this.id);
   
}
emp: Student[]=[
  new Student(10,"Vineela","cse"),
  new Student(21,"Ramesh","Mechanical"),
  new Student(30,"Abhay","ECE"),
  new Student(40,"John","EEE"),
  new Student(25,"Rahul","Civil")
]
flag:number=0;
l:number=0;
name:string;
dept:string;
ngOnInit(): void {
  console.log("hello");
  for (let index = 0; index < this.emp.length; index++) {
  
    if(this.id==this.emp[index].id){
     this.flag=1;
    this.l=index}
  }
  this.name=this.emp[this.l].name;
  this.id=this.emp[this.l].id;
  this.dept=this.emp[this.l].major;
  
}



}
