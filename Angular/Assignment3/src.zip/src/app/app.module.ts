import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CollegeComponent } from './college/college.component';
import { AboutComponent } from './about/about.component';
import { StudentComponent } from './student/student.component';
import { RouterModule, Routes } from '@angular/router';
const app:Routes = [
  {
    path:'clg',
    component:CollegeComponent
  },
  {
    path:'about',
    component:AboutComponent
  },
 
  
  {
    path:'student/:id',
    component:StudentComponent
  }
]
@NgModule({
  declarations: [
    AppComponent,
    CollegeComponent,
    AboutComponent,
    StudentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(app)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
