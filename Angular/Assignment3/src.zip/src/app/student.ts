export class Student{
    id:number;
    name:string;
    major:string;
   

    constructor(id:number,name:string,major:string){
        this.id=id;
        this.name=name;
        this.major=major;
        
    }

}