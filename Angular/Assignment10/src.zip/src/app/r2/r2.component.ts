import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-r2',
  templateUrl: './r2.component.html',
  styleUrls: ['./r2.component.css']
})
export class R2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
