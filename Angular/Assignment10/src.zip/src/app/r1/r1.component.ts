import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-r1',
  templateUrl: './r1.component.html',
  styleUrls: ['./r1.component.css']
})
export class R1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
