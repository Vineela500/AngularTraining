export class Railway{
    name:string;
   
    train_no:number;
    from:string;
    to:string;

    
}