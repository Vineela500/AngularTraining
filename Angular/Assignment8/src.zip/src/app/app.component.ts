import { Component } from '@angular/core';
import { NewServiceService } from './new-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  disable:boolean =false;
  title = 'proj1';
  name:string = "Vineela";
  twoway:string="";
  img:string ="../assets/download.jpg";
  img1:string="../assets/diagoona-bg-3.jpg";
  h1color:string="Aqua";
  info:string="Leh is the best place to visit";
  months = ["March","April","May","June","July","August","September","October"];
  onButtonClick($event) {
    console.log("button clicked",$event);
    alert("Button Clicked");
  }
  chageColor(){
       this.h1color="Crimson";
  }
  constructor(private myservice:NewServiceService){

  }
  today:Date;
  getDate(){
    this.today=this.myservice.showDate();
  }
  message1:string="My new component";
  p:string ;
  parent(e){
   this.p=e;
    alert(this.p);
  }
}
