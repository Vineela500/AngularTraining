import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NewServiceService {

  constructor() { }
  showDate(): Date
  {
    let today=new Date();
    return today;
  }
}
