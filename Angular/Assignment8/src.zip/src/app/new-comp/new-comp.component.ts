import { Component, Input, OnInit, Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-new-comp',
  templateUrl: './new-comp.component.html',
  styleUrls: ['./new-comp.component.css']
})
export class NewCompComponent implements OnInit {

  constructor() { }
  @Input() message;
  @Output() public child = new EventEmitter();
  ngOnInit(): void {
  }
  click():void {
    this.child.emit("Message from child to parent using Event Emitter");
  }

}
