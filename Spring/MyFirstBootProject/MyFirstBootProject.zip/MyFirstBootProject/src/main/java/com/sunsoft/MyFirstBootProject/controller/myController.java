package com.sunsoft.MyFirstBootProject.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class myController {
@RequestMapping("/test")
public String testFunction() {
	String str="This is my first Spring Boot Application Rest controller";
	System.out.println("This is seen in console");
	return str;
}
}
