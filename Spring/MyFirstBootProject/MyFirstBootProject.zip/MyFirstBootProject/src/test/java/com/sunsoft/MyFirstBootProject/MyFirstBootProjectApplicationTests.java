package com.sunsoft.MyFirstBootProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstBootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
