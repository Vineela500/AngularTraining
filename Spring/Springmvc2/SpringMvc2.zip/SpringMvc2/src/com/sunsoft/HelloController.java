package com.sunsoft;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController{
	@RequestMapping("/hello")
	public String helloWorld(Model m) {
		String message="Hello";
		System.out.println(message);
		m.addAttribute("message",message);
		return "hellopage";
	}
}