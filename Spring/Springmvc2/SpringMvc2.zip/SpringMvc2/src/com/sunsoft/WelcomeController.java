package com.sunsoft;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class WelcomeController {
	@RequestMapping("/welcome/{id}")
	public String helloWorld(@RequestParam("id1") int id1,@PathVariable("id") int id,Model m) {
		String message="Welcome"+id+" "+id1;
		System.out.println(message);
		m.addAttribute("message",message);
		return "hellopage";
	}

}
