import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

//import antlr.collections.List;
//import org.hibernate.mapping.List;

public class Client {
	private static SessionFactory factory;
	public static void getSessionFactory()
	{
		try {
			Configuration conf = new Configuration().configure();
			StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder().applySettings(conf.getProperties());
		    factory=conf.buildSessionFactory(builder.build());
		    
		}
		catch(Throwable ex){
			System.err.println("Failed to create sessionFactory object."+ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
	public static void main(String args[]) {
		try {
			getSessionFactory();
			Client client_1=new Client();
			Address add1=new Address("Karol bagh","Mehdipatnam","India","543");
			Employee emp1=new Employee(10,"Vineela","Reddy", 1000);
			emp1.setAdd(add1);
			client_1.InsertData(emp1, add1);
			//emp1.setAddress(add1);
			
			//client_1.InsertRecordIntoDatabase(1, "Roshni", "Malhotra", 20000);
			//client_1.UpdateRecordIntoDatabase(1, 4000);
			//client_1.DeleteRecord(1);
			//client_1.DisplayRecord();
			//client_1.DisplayRecords_NavigateSQL();
		}
		catch(HibernateException e) {
			System.out.println("Exception is" +e);
		}
	}
	public void InsertData(Employee emp, Address add) {
		System.out.println("Hello");
		Session session = factory.openSession();
		Transaction tx=session.beginTransaction();
		System.out.println("Hello");
		session.save(emp);
		session.save(add);
		System.out.println("Saved");
		tx.commit();
		System.out.println("Success");
		System.out.println("Employee and Address are added into database");
		session.close();
	}
	
	
}
