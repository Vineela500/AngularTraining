import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

//import antlr.collections.List;
//import org.hibernate.mapping.List;

public class Client {
	private static SessionFactory factory;
	public static void getSessionFactory()
	{
		try {
			Configuration conf = new Configuration().configure();
			StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder().applySettings(conf.getProperties());
		    factory=conf.buildSessionFactory(builder.build());
		    
		}
		catch(Throwable ex){
			System.err.println("Failed to create sessionFactory object."+ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
	public static void main(String args[]) {
		try {
			getSessionFactory();
			Client client_1=new Client();
			client_1.InsertRecordIntoDatabase(36, "Roshni", "Malhotra", 20000);
			//client_1.UpdateRecordIntoDatabase(1, 4000);
			//client_1.DeleteRecord(1);
			//client_1.DisplayRecord();
			//client_1.DisplayRecords_NavigateSQL();
		}
		catch(HibernateException e) {
			System.out.println("Exception is" +e);
		}
	}
		
	public void InsertRecordIntoDatabase(int id,String fname,String lname,int salary) throws HibernateException{
			Session session =factory.openSession();
			Transaction tx=session.beginTransaction();
			Employee e1=new Employee(id,fname,lname,salary);
			session.save(e1);
			tx.commit();
			session.clear();
		}
	public void UpdateRecordIntoDatabase(Integer EmpId,int salary) {
		Session session= factory.openSession();
		Transaction tx=session.beginTransaction();
		Employee employee=(Employee) session.get(Employee.class, EmpId);
		employee.setSalary(salary);
		session.saveOrUpdate(employee);
		tx.commit();
		session.close();
	}
	public void DeleteRecord(Integer EmployeeID) throws HibernateException
	{
		Session session = factory.openSession();
		Transaction tx=session.beginTransaction();
		Employee employee=(Employee) session.get(Employee.class, EmployeeID);
		session.delete(employee);
		tx.commit();
		session.close();
		
	}
	
	public void DisplayRecord() throws HibernateException {
		Session session = factory.openSession();
		Criteria cr = session.createCriteria(Employee.class);
		cr.add(Restrictions.gt("salary",6000));
		List empLst =   cr.list();
		
		for(Iterator iterator = 
				empLst.iterator(); iterator.hasNext();) {
			Employee emp=(Employee) iterator.next();
			System.out.println("First name"+ emp.getFirstName());
			System.out.println("Last name"+emp.getLastName());
			System.out.println("salary"+emp.getSalary());
		}
	}
	
	public void DisplayRecords_NavigateSQL() throws HibernateException{
		Session session= factory.openSession();
		String sql="SELECT * FROM hibernate1 where salary>5000";
		SQLQuery query = session.createSQLQuery(sql);
		query.addEntity(Employee.class);
		List results=query.list();
		for(Iterator iterator= results.iterator();iterator.hasNext();) {
			Employee emp=(Employee) iterator.next();
			System.out.println("First name "+emp.getFirstName());
			System.out.println("Last name "+emp.getLastName());
			System.out.println("salary "+emp.getSalary());
		}
	}
}
