package com.sunsoft;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloWorldController{
	@RequestMapping("/hello")
	public String helloWorld(HttpServletRequest req,HttpServletResponse res) {
		int message=req.getParameter("id");
		System.out.println(message);
		m.addAttribute("message",message);
		return "hellopage";
	}
}
