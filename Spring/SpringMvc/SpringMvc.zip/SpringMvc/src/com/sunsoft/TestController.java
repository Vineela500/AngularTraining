package com.sunsoft;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {
	
	    @RequestMapping("/hello2")
		public String helloWorld(Model m) {
	    	System.out.println("hello");
	    	//String message="Given data "+id+" "+name+" "+ id1 +" .";
	    	m.addAttribute("message", "message");
	    	m.addAttribute("test", "Test");
	    	return "welcomepage";
	    }
	
}
