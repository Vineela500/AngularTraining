package com.sunsoft.MyFirstDBBoot.controller;

public class StudentController {

}
