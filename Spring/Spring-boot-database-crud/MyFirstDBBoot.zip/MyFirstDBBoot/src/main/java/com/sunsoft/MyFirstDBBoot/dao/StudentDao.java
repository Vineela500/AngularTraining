package com.sunsoft.MyFirstDBBoot.dao;

public class StudentDao {

}
