package com.sunsoft.MyFirstDBBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstDbBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstDbBootApplication.class, args);
	}

}
