package com.sunsoft.MyFirstDBBoot.model;

public class StudentData {

}
