package com.sunsoft.MyFirstDBBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstDbBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
