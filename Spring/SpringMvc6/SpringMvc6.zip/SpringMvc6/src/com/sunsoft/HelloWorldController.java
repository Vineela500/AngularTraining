package com.sunsoft;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloWorldController {
	List<Employee> empList = new ArrayList<Employee>();
	@RequestMapping("/insert")
	public String insert() {
		return "insert";
	}
	@RequestMapping("/insert1")
	public String insert1(HttpServletRequest req,Model m) {
		String name=req.getParameter("name");
		String id=req.getParameter("id");
		String dept=req.getParameter("dept");
		String salary=req.getParameter("sal");
		//Employee emp=new Employee(id,name,dept,salary);
		
		empList.add(new Employee(id,name,dept,salary));
		m.addAttribute("message", "Inserted Successfully");
		return "success";
		
	}
	@RequestMapping("/display")
	public ModelAndView display(Model m) {
		ModelAndView mv = new ModelAndView();

		mv.setViewName("inserted");
		mv.addObject("empList", empList);
		return mv;
	}
	@RequestMapping("/update")
	public String update() {
		return "update";
	}
	@RequestMapping("/update1")
	public String update1(HttpServletRequest req,Model m) {
		String id=req.getParameter("id");
		String name=req.getParameter("name");
		String dept=req.getParameter("dept");
		String sal=req.getParameter("sal");
		for(Employee i:empList) {
			if(i.id.equals(id)) {
				i.setName(name);
				i.setDept(dept);
				i.setSal(sal);
			}
		}
		m.addAttribute("message", "Updated Successfully");
		return "success";
	}
	@RequestMapping("/delete")
	public String delete() {
		return "delete";
	}
	@RequestMapping("/delete1")
	public String delete1(HttpServletRequest req,Model m) {
		String id=req.getParameter("id");
		
		for(Employee i:empList) {
			if(i.id.equals(id)) {
				empList.remove(i);
			}
		}
		m.addAttribute("message", "Deleted Successfully");
		return "success";
	}
	/*public ModelAndView helloWorld(Model m,HttpServletRequest req,HttpServletResponse res, @RequestParam("basic") int basic, @RequestParam("hra") int hra, @RequestParam("da") int da, @RequestParam("ded") int ded, @RequestParam("it") int it,@PathVariable("id1") int id1) {
		String name=req.getParameter("name");
		String pass=req.getParameter("pass");
		ArrayList<String> arr=new ArrayList<String>();
		arr.add(name);
		arr.add(pass);
		List<String> empList = new ArrayList<>();
		empList.add("Atul");
		empList.add("Abhinav");
		empList.add("Prince");
		empList.add("Gaurav");

		ModelAndView mv = new ModelAndView();

		mv.setViewName("hello");
		mv.addObject("empList", empList);

		return mv;
		
	}*/

}
