package Employee;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {
  public static void main(String args[]) {
	ApplicationContext context=new ClassPathXmlApplicationContext("helloBeans.xml");
	Emp obj = (Emp) context.getBean("hello");
	
	System.out.println("Hello");
	System.out.println(obj.getEmpId());
	System.out.println(obj.getName());
	System.out.println(obj.getDept());
	System.out.println(obj.getDesignation());
}
}
