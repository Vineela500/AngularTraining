package pack1;

public class Processor {
	public Processor() {
		System.out.println("Constructor");
	}
	public void display(String processor) {
		  System.out.println(processor);
	  }
}
