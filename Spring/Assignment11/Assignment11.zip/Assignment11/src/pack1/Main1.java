package pack1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main1 {
	public static void main(String args[]) {
		ApplicationContext con=new ClassPathXmlApplicationContext("beans.xml");
		System1 sys=(System1) con.getBean("system");
		sys.display();
	}

}
