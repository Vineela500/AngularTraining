package com.sunsoft;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloWorldController {
@RequestMapping("/name")
public String helloWorld(Model m,HttpServletRequest req,HttpServletResponse res) {
	String name=req.getParameter("name");
	System.out.println(name);
	m.addAttribute("name", name);
	return "hello";
	
}
}
