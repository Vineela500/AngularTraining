
public class Processor {
  public void display(String processor) {
	  System.out.println(processor);
  }
}
