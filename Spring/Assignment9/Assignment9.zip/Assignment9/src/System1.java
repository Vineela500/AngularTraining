
public class System1 {
	
		
		private int ram;
		private String company;
		private int cost;
		private Processor pro;
		private String proce;
		public String getProce() {
			return proce;
		}
		public void setProce(String proce) {
			this.proce = proce;
		}
		public int getRam() {
			return ram;
		}
		public void setRam(int ram) {
			this.ram = ram;
		}
		public String getCompany() {
			return company;
		}
		public void setCompany(String company) {
			this.company = company;
		}
		public int getCost() {
			return cost;
		}
		public void setCost(int cost) {
			this.cost = cost;
		}
		public Processor getPro() {
			return pro;
		}
		public void setPro(Processor pro) {
			this.pro = pro;
		}
		public void display() {
			System.out.println(this.ram+" "+this.company+" "+this.cost);
			pro.display(proce);
			
		}
		}

