package com.example.repo;

import org.springframework.stereotype.Repository;

import com.example.dao.Investment;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface InvestRepo extends JpaRepository<Investment, Long> {

}
