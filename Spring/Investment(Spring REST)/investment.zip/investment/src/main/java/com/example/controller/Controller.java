package com.example.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.dao.*;
import com.example.exception.RecordNotFoundException;
import com.example.repo.InvestRepo;


@RestController
@RequestMapping("/")
@CrossOrigin
public class Controller {
	@Autowired
	InvestRepo investRepo;
	
	@GetMapping("/emp")
	public List<Investment> getAll(){
		return investRepo.findAll();
	}
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces="application/json", consumes="application/json")
	public ResponseEntity<String> auth (@RequestBody Investment emp){
		Investment e = investRepo.getOne(emp.getId());
		System.out.println("hello");
		System.out.println("emp u"+emp.getUsername());
		System.out.println("e u"+e.getUsername());
		System.out.println("emp p"+emp.getPassword());
		System.out.println("e p"+e.getPassword());
		 System.out.println("hello");
	     if(e == null) {
	            throw new RuntimeException("User does not exist.");
	        }
	     if(!e.getPassword().equals(emp.getPassword())){
	            throw new RuntimeException("Password mismatch.");
	        }
	     System.out.println("Login Success");
	     return new ResponseEntity<>("Login Success",HttpStatus.OK);
	     
	}
	
	@RequestMapping(value = "/name", method = RequestMethod.POST, produces="application/json", consumes="application/json")
	public ResponseEntity<String> fullname (@RequestBody Investment emp){
	System.out.println(emp.getFirstname()+" "+emp.getLastname());
	return new ResponseEntity<>("Login Success",HttpStatus.OK);
	}
	}
