package com.sunsoft.MyFirstDBBoot1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EntityScan(basePackages= {"com.sunsoft.MyFirstDBBoot1"})
@ComponentScan(basePackages= {"com.sunsoft.MyFirstDBBoot1"})
public class MyFirstDbBoot1Application {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstDbBoot1Application.class, args);
	}

}
