package com.sunsoft.MyFirstDBBoot1.repository;

import org.springframework.data.repository.CrudRepository;

import com.sunsoft.MyFirstDBBoot1.model.StudentData;

public interface StudentRepository extends CrudRepository<StudentData, Integer>{

}
