package com.sunsoft.MyFirstDBBoot1.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunsoft.MyFirstDBBoot1.dao.StudentDao;
import com.sunsoft.MyFirstDBBoot1.model.StudentData;

@RestController
public class StudentController {
	@Autowired
	StudentDao studentDao;
	
	@RequestMapping("/insert")
	public String insert() {
		StudentData obj=new StudentData();
		obj.setId(12);
		obj.setName("Roma");
		obj.setDept("ECE");
		obj.setMarks(50);
		StudentData obj1=new StudentData();
		obj1.setId(14);
		obj1.setName("Avni");
		obj1.setDept("Mech");
		obj1.setMarks(90);
		System.out.println("Inside insert func of controller");
		studentDao.insert(obj1);
		return "Data Successfully inserted";
	}
	@RequestMapping("/display")
	public List<StudentData> display(){
		List<StudentData> ls=studentDao.display();
		return ls;
	}	
	@RequestMapping("/update/{id1}")
	public String update(@RequestParam("id") int id,@RequestParam("name") String name,@RequestParam("dept") String dept,@RequestParam("marks") int marks,@PathVariable("id1") int id1)
	{ 
		StudentData obj=new StudentData();
		obj.setId(id);
		obj.setName(name);
		obj.setDept(dept);
		obj.setMarks(marks);
		studentDao.update(obj);
		return "Updated Successfully";
		
	}
	@RequestMapping("/delete/{id}")
	public String delete(@PathVariable int id) {
		studentDao.delete(id);
		return "Deleted Successfully";
	}
	
}
