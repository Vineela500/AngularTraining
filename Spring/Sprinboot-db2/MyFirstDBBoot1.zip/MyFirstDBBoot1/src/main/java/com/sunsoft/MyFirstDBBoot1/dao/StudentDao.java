package com.sunsoft.MyFirstDBBoot1.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunsoft.MyFirstDBBoot1.model.StudentData;
import com.sunsoft.MyFirstDBBoot1.repository.StudentRepository;

@Service
public class StudentDao {
@Autowired
StudentRepository studentRepository;
public void insert(StudentData obj) {
	studentRepository.save(obj);
}
public List<StudentData> display(){
	List<StudentData> ls=(List<StudentData>) studentRepository.findAll();
	return ls;
}
public void update(StudentData obj) {
	if(studentRepository.existsById(obj.getId())) {
	studentRepository.save(obj);
	}
}
public void delete(int id) {
	studentRepository.deleteById(id);
 
}

}
